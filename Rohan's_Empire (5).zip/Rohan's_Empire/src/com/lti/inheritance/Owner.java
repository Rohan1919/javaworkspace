package com.lti.inheritance;

public class Owner extends Person {
	
	private String profession;

	public String getProfession() {
		return profession;
	}

	public void setProfession(String profession) {
		this.profession = profession;
	}
	
}
