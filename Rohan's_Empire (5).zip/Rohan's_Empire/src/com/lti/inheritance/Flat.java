package com.lti.inheritance;

public class Flat extends Property {
	
	private String type;
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
