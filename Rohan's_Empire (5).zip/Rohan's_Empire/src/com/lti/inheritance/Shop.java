package com.lti.inheritance;

public class Shop extends Property{
	private int licenseNo;

	public int getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(int licenseNo) {
		this.licenseNo = licenseNo;
	}
	

}
