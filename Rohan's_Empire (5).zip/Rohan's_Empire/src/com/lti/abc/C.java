package com.lti.abc;

public class C {
	int b=10;
	void check(){
		A a=new A();
		a.var1=10;
		a.var2=20;
		a.var3=20;
		a.var4=20;
	}

}
