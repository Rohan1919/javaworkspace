package com.lti.abc;

public class A {
	private int var1;
	int var2;//default
	protected int var3;
	public int var4;

}
