package com.lti.rawexample;



public class Ex1{

	
	public static void main(String[] args) {
		
	}

}
