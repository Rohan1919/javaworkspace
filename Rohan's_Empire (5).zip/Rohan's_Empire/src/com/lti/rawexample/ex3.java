package com.lti.rawexample;

abstract public class ex3 {
	public void f1(){
		System.out.println("hello this is f1");
		
	}
	abstract public void f2();

}
