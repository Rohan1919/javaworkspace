
package com.lti.wrapperclasses;

public class WrapperClass {
	public static void main(String[] args) {
		
	
	    int a=10;
	    Integer b=10;
	    a= 20;
	    b= 20;
	    
	    //comman function of wrapper classses
	    //converting String to int
	    String s="100";
	    int si=Integer.parseInt(s);
	    //converting int to String
	    int x=200;
	    String sx=Integer.toString(x);
	    //coverting String to Integer
	     
	    String t="100";
	    
	}

}
