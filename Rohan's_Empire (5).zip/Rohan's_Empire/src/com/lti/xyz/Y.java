package com.lti.xyz;

import com.lti.abc.A;

public class Y{
	void check(){
		A a=new A();
		a.var1=10;
		a.var2=20;
		a.var3=20;
		a.var4=20;

}
