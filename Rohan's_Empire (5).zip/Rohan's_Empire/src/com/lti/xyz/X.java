package com.lti.xyz;

import com.lti.abc.A;

public class X extends A {
	void check(){
		var1=10;
		var2=20;
		var3=30;
		var4=40;
		
	}
	

}
