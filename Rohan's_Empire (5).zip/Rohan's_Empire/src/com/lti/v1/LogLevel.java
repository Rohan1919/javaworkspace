package com.lti.v1;

public enum LogLevel {
	INFO,WARN,ERROR;

}
