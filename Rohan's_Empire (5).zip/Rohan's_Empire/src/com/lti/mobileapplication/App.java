package com.lti.mobileapplication;

public class App {
	public static void main(String[] args) {
		Launcher launcher =new Launcher();
		
		MyMobileApp app1=new MyMobileApp();
		launcher.launch(app1);
	}

}
