package com.lti.mobileapplication;

public interface MobileApplication {
	public void start();
	public void pause();
	public void stop();
	

}
