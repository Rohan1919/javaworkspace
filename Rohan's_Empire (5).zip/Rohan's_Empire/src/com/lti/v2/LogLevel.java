package com.lti.v2;

public enum LogLevel {
	INFO,WARN,ERROR;

}
