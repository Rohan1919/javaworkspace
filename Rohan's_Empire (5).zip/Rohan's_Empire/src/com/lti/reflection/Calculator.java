package com.lti.reflection;

public class Calculator {
	public int add(int x,int y){
		return x+y;
	}

}
