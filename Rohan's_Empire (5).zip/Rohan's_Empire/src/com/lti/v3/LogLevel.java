package com.lti.v3;

public enum LogLevel {
	INFO,WARN,ERROR;

}
