
public enum ConsultingType {
	MODULAR_KITCHEN,
	FLOORING_AND_CEILING,
	FULL_HOME_RENOVATION;

}
